﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio.Models;
namespace Negocio.Helpers
{
    public static class ClienteSeleccionadoResult
    {
        public static Cliente? Cliente { get; set; }
    }
}

