using Negocio.Models;

namespace Negocio.Helpers
{
    public  class EstadoSeleccionProducto
    {
        public static Producto? ProductoSeleccionado { get; set; }
        //public static VentaDet? DetalleEnEdicion { get; set; }

        //public static void Limpiar()
        //{
        //    ProductoSeleccionado = null;
        //    DetalleEnEdicion = null;
        //}

        private static readonly Lazy<EstadoSeleccionProducto> _instance =
    new Lazy<EstadoSeleccionProducto>(() => new EstadoSeleccionProducto());

        public static EstadoSeleccionProducto Instance => _instance.Value;

        //private static EstadoSeleccionProducto? _instance;
        //public static EstadoSeleccionProducto Instance => _instance ??= new EstadoSeleccionProducto();

        public object? EstadoPaginaActual { get; set; }
        //public Producto? ProductoSeleccionado { get; set; }
        // M�todo para guardar estado
        // Diccionario para guardar m�ltiples estados por tipo de p�gina
        private readonly Dictionary<Type, object> _pageStates = new();
        public void SavePageState<TPage>(object state)
        {
            _pageStates[typeof(TPage)] = state;
        }
        // M�todo para recuperar estado
        public TState GetPageState<TPage, TState>() where TState : class
        {
            if (_pageStates.TryGetValue(typeof(TPage), out var state))
            {
                return state as TState;
            }
            return null;
        }
    }
}