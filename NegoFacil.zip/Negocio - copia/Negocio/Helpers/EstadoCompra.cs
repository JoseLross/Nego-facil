﻿using Negocio.Models;

namespace Negocio.Helpers
{
    public static class EstadoSeleccionCompra
    {
        public static CompraDetallePageState? EstadoActual { get; set; }

        public static void Limpiar()
        {
            EstadoActual = null;
        }
    }
}
