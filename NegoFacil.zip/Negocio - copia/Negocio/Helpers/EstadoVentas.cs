﻿using Negocio.Models;

namespace Negocio.Helpers
{
    public static class EstadoSeleccionVenta
    {
        public static VentaDetallePageState? EstadoActual { get; set; }

        public static void Limpiar()
        {
            EstadoActual = null;
        }
    }
}