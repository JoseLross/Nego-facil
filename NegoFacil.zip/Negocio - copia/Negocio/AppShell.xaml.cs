﻿using Negocio.Views;


namespace Negocio
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();

            Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
            Routing.RegisterRoute(nameof(RegistroPage), typeof(RegistroPage));
            Routing.RegisterRoute(nameof(RecuperarContrasenaPage), typeof(RecuperarContrasenaPage));

            Routing.RegisterRoute(nameof(CompraDetallePage), typeof(CompraDetallePage));
            Routing.RegisterRoute(nameof(VentaDetallePage), typeof(VentaDetallePage));
            Routing.RegisterRoute(nameof(SeleccionProveedorPage), typeof(SeleccionProveedorPage));
            Routing.RegisterRoute(nameof(SeleccionClientePage), typeof(SeleccionClientePage));
            Routing.RegisterRoute(nameof(SeleccionProductoPage), typeof(SeleccionProductoPage));

            //Shell.Current.GoToAsync($"//{nameof(LoginPage)}");


        }
    }
}
