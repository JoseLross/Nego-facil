﻿using Negocio.Views;
namespace Negocio
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            //MainPage = new AppShell();
            MainPage = new NavigationPage(new LoginPage());
            // Navegamos al LoginPage de forma segura
            //Application.Current.Dispatcher.Dispatch(async () =>
            //{
            //    await Shell.Current.GoToAsync($"//{nameof(LoginPage)}");
            //});
        }
    }
}
