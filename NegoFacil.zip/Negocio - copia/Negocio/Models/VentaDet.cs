using SQLite;

namespace Negocio.Models
{
    public class VentaDet
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public int HeadId { get; set; }
        public int Prodid { get; set; }
        public decimal PrecioVen { get; set; }
        public decimal Cantidad { get; set; }
        public bool IVA { get; set; }
    }
}