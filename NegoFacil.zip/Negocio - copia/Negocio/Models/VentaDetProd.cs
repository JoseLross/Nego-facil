﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;
namespace Negocio.Models
{
    // Models/Cliente.cs y Models/Proveedor.cs (idénticos en estructura)
    public class VentaDetProd
    {
        public VentaDet? VentaDetReg { get; set; }
        public string? ProdDescr { get; set; }

        //public int Id { get; set; }

        //public int HeadId { get; set; } // FK a CompraHead
        //public int Prodid { get; set; } // FK a Producto
        //public decimal PrecioCom { get; set; }
        //public decimal Cantidad { get; set; }
        //public bool IVA { get; set; }
    }

}

