﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio.Models;

namespace Negocio.Helpers
{
    public class CompraDetallePageState
    {
        public bool formulariovisible { get; set; }
        public CompraDet? detalleactual { get; set; }
        // Agrega otras propiedades según necesites
    }

}
