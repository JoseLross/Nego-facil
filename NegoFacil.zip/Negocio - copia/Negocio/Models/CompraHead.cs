﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;
namespace Negocio.Models
{
    // Models/Cliente.cs y Models/Proveedor.cs (idénticos en estructura)
    public class CompraHead
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public int Provid { get; set; } // FK a Proveedor
        public DateTime Fecha { get; set; }
        public string Albaran { get; set; }
        public string Observa { get; set; }
    }

}
