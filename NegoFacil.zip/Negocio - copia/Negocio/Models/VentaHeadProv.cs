﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio.Models
{
    public class VentaHeadProv
    {
        //public int Id { get; set; }
        //public int Provid { get; set; } // FK a Proveedor
        //public DateTime Fecha { get; set; }
        //public string Albaran { get; set; }
        //public string Observa { get; set; }
        public VentaHead VentaReg { get; set; }
        public string? ClieDescr { get; set; }
    }
}

