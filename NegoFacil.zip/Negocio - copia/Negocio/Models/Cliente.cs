﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;
namespace Negocio.Models
{
    // Models/Cliente.cs y Models/Proveedor.cs (idénticos en estructura)
    public class Cliente
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string? Codigo { get; set; }
        public string? Descrip { get; set; }
        public string? Telef { get; set; }
        public string? Direc1 { get; set; }
        public string? Direc2 { get; set; }
        public string? Ciudad { get; set; }
        public string? Pais { get; set; }
    }

}
