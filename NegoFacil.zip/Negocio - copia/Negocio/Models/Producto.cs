using SQLite;

namespace Negocio.Models
{
    public class Producto
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string Refer { get; set; }
        public string Descrip { get; set; }
        public string UMed { get; set; }
        public decimal Stock { get; set; }
    }
}