﻿using SQLite;
using Negocio.Models;

namespace Negocio.Data
{
    public class AppDbContext
    {
        private readonly SQLiteAsyncConnection _database;

        public AppDbContext(string dbPath)
        {
            _database = new SQLiteAsyncConnection(dbPath);

            // Crear tablas si no existen
            _database.CreateTableAsync<Cliente>().Wait();
            _database.CreateTableAsync<Proveedor>().Wait();
            _database.CreateTableAsync<Producto>().Wait();
            _database.CreateTableAsync<CompraHead>().Wait();
            _database.CreateTableAsync<CompraDet>().Wait();
            _database.CreateTableAsync<VentaHead>().Wait();
            _database.CreateTableAsync<VentaDet>().Wait();
            _database.CreateTableAsync<Usuario>().Wait();
        }
        //USUARIOS
        public Task<List<Usuario>> GetUsuariosAsync() =>
            _database.Table<Usuario>().ToListAsync();

        public Task<Usuario> GetUsuarioByNombreAsync(string nombre) =>
            _database.Table<Usuario>().FirstOrDefaultAsync(u => u.Nombre == nombre);

        public Task<Usuario> GetUsuarioByEmailAsync(string email) =>
            _database.Table<Usuario>().FirstOrDefaultAsync(u => u.Email == email);
        public async Task<Usuario?> GetUsuarioByNameYContrasena(string name, string contrasena)
        {
            return await _database.Table<Usuario>()
                .Where(u => u.Nombre == name && u.Contrasena == contrasena)
                .FirstOrDefaultAsync();
        }
        public async Task<Usuario?> GetUsuarioByEmailYContrasena(string email, string contrasena)
        {
            return await _database.Table<Usuario>()
                .Where(u => u.Email == email && u.Contrasena == contrasena)
                .FirstOrDefaultAsync();
        }

        public Task<int> InsertUsuarioAsync(Usuario usuario) =>
            _database.InsertAsync(usuario);

        public Task<int> UpdateUsuarioAsync(Usuario usuario) =>
            _database.UpdateAsync(usuario);


        // CLIENTES
        public Task<List<Cliente>> GetClientesAsync() => _database.Table<Cliente>().ToListAsync();
        public Task<Cliente?> GetClienteByIdAsync(int id) =>
                    _database.Table<Cliente>().Where(p => p.Id == id).FirstOrDefaultAsync();
        public Task<int> InsertClienteAsync(Cliente item) => _database.InsertAsync(item);
        public Task<int> UpdateClienteAsync(Cliente item) => _database.UpdateAsync(item);
        public Task<int> DeleteClienteAsync(Cliente item) => _database.DeleteAsync(item);

        // PROVEEDORES
        public Task<List<Proveedor>> GetProveedoresAsync() => _database.Table<Proveedor>().ToListAsync();
        public Task<Proveedor?> GetProveedorByIdAsync(int id) =>
                    _database.Table<Proveedor>().Where(p => p.Id == id).FirstOrDefaultAsync();
        public Task<int> InsertProveedorAsync(Proveedor item) => _database.InsertAsync(item);
        public Task<int> UpdateProveedorAsync(Proveedor item) => _database.UpdateAsync(item);
        public Task<int> DeleteProveedorAsync(Proveedor item) => _database.DeleteAsync(item);

        // PRODUCTOS
        public Task<List<Producto>> GetProductosAsync() => _database.Table<Producto>().ToListAsync();
        public Task<Producto?> GetProductoByIdAsync(int id) =>
                    _database.Table<Producto>().Where(p => p.Id == id).FirstOrDefaultAsync();
        public Task<int> InsertProductoAsync(Producto item) => _database.InsertAsync(item);
        public Task<int> UpdateProductoAsync(Producto item) => _database.UpdateAsync(item);
        public Task<int> DeleteProductoAsync(Producto item) => _database.DeleteAsync(item);
        public async Task<bool> SumarStockProductoAsync(int productoId, decimal cantidadASumar)
        {
            var producto = await _database.Table<Producto>()
                                          .Where(p => p.Id == productoId)
                                          .FirstOrDefaultAsync();

            if (producto == null)
                return false; // No se encontró el producto

            producto.Stock += cantidadASumar;

            await _database.UpdateAsync(producto);
            return true;
        }

        // COMPRAS - CABECERA
        public Task<List<CompraHead>> GetCompraHeadsAsync() => _database.Table<CompraHead>().ToListAsync();
        public Task<int> InsertCompraHeadAsync(CompraHead item) => _database.InsertAsync(item);
        public Task<int> UpdateCompraHeadAsync(CompraHead item) => _database.UpdateAsync(item);
        public Task<int> DeleteCompraHeadAsync(CompraHead item) => _database.DeleteAsync(item);

        // COMPRAS - DETALLE
        public Task<List<CompraDet>> GetCompraDetsByHeadIdAsync(int headId) =>
            _database.Table<CompraDet>().Where(d => d.HeadId == headId).ToListAsync();
        public Task<CompraDet?> GetCompraDetByIdAsync(int id) =>
            _database.Table<CompraDet>().Where(p => p.Id == id).FirstOrDefaultAsync();

        public Task<int> InsertCompraDetAsync(CompraDet item) => _database.InsertAsync(item);
        public Task<int> UpdateCompraDetAsync(CompraDet item) => _database.UpdateAsync(item);
        public Task<int> DeleteCompraDetAsync(CompraDet item) => _database.DeleteAsync(item);

        // VENTAS - CABECERA
        public Task<List<VentaHead>> GetVentaHeadsAsync() => _database.Table<VentaHead>().ToListAsync();
        public Task<int> InsertVentaHeadAsync(VentaHead item) => _database.InsertAsync(item);
        public Task<int> UpdateVentaHeadAsync(VentaHead item) => _database.UpdateAsync(item);
        public Task<int> DeleteVemtaHeadAsync(VentaHead item) => _database.DeleteAsync(item);

        // VENTAS - DETALLE
        public Task<List<VentaDet>> GetVentaDetsByHeadIdAsync(int headId) =>
            _database.Table<VentaDet>().Where(d => d.HeadId == headId).ToListAsync();
        public Task<VentaDet?> GetVentaDetByIdAsync(int id) =>
            _database.Table<VentaDet>().Where(p => p.Id == id).FirstOrDefaultAsync();

        public Task<int> InsertVentaDetAsync(VentaDet item) => _database.InsertAsync(item);
        public Task<int> UpdateVentaDetAsync(VentaDet item) => _database.UpdateAsync(item);
        public Task<int> DeleteVentaDetAsync(VentaDet item) => _database.DeleteAsync(item);
    }
}


