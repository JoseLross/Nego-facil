﻿using System;
using System.IO;
using Negocio.Data;

namespace Negocio
{
    public static class DatabaseService
    {
        static AppDbContext database;

        public static AppDbContext Database
        {
            get
            {
                if (database == null)
                {
                    var dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "negocio.db3");
                    database = new AppDbContext(dbPath);
                }
                return database;
            }
        }
    }
}

