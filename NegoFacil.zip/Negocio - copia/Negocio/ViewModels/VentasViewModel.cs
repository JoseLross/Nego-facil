﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Maui.Devices.Sensors;
using Negocio.Models;
using Negocio.Views;

namespace Negocio.ViewModels
{
    public class VentasViewModel : BaseViewModel
    {
        private string _filtro;
        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }
        private VentaHeadProv _ventaActual = new();
        private bool _formularioVisible;

        public VentaHeadProv VentaActual
        {
            get => _ventaActual;
            set 
            {
                if (SetProperty(ref _ventaActual, value) && value.VentaReg != null)
                {
                    FormularioVisible = true;
                    // sincroniza automáticamente el proveedor seleccionado
                    ClienteSeleccionado = Clientes.FirstOrDefault(p => p.Id == value.VentaReg.Clieid);

                }
            }
        }
        private Cliente _clienteSeleccionado;
        public Cliente ClienteSeleccionado
        {
            get => _clienteSeleccionado;
            set
            {
                if (SetProperty(ref _clienteSeleccionado, value) && value != null)
                {
                    VentaActual.VentaReg.Clieid = value.Id;
                }
            }
        }

        public ObservableCollection<Cliente> Clientes { get; set; } = new();

        private async void CargarClientes()
        {
            var lista = await DatabaseService.Database.GetClientesAsync();
            Clientes.Clear();
            foreach (var item in lista)
                Clientes.Add(item);
        }

        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand IrADetalleCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand SeleccionarClienteCommand { get; }



        public VentasViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            NuevoCommand = new Command(Nuevo);
            IrADetalleCommand = new Command(IrADetalle);
            CancelarCommand = new Command(Cancel);
            SeleccionarClienteCommand = new Command(SeleccionarCliente);


            CargarVentas();
            CargarClientes();
        }
        private async void SeleccionarCliente()
        {
            await Shell.Current.GoToAsync(nameof(SeleccionClientePage));
        }

        public ObservableCollection<VentaHeadProv> Ventas { get; set; } = new();
        private async void CargarVentas()
        {
            /*
            var lista = await DatabaseService.Database.GetVentaHeadsAsync();
            Ventas.Clear();
            foreach (var item in lista)
            {
                Cliente cliente = await DatabaseService.Database.GetClienteByIdAsync(item.Clieid);
                Ventas.Add(new VentaHeadProv
                {
                    VentaReg = item,
                    ClieDescr = cliente?.Descrip ?? "(Cliente desconocido)"
                });
            }
            */
            var lista2 = await DatabaseService.Database.GetVentaHeadsAsync();
            TodasLasVentas = lista2;
            AplicarFiltro();
        }

        private List<VentaHead> TodasLasVentas { get; set; } = new();

        private async void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodasLasVentas
                : TodasLasVentas.Where(p =>
                    (p.Albaran?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Albaran?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            Ventas.Clear();
            foreach (var item in resultado)
            {
                Cliente cliente = await DatabaseService.Database.GetClienteByIdAsync(item.Clieid);
                Ventas.Add(new VentaHeadProv
                {
                    VentaReg = item,
                    ClieDescr = cliente?.Descrip ?? "(Cliente desconocido)"
                });
            }
        }

        private async void Guardar()
        {
            if (FormularioVisible)
            {
                var _ventareg = VentaActual.VentaReg;
                if (_ventareg.Id == 0)
                    await DatabaseService.Database.InsertVentaHeadAsync(_ventareg);
                else
                    await DatabaseService.Database.UpdateVentaHeadAsync(_ventareg);

                CargarVentas();
                FormularioVisible = false;
                VentaActual = new VentaHeadProv();
                Nuevo(false);
            }
        }

        private async void Eliminar()
        {
            var _comprareg = VentaActual.VentaReg;
            if (_comprareg.Id == 0) return;

            bool confirmar = await Shell.Current.DisplayAlert(
                "Confirmar eliminación",
                "¿Estás seguro de que quieres eliminar esta venta?",
                "Sí", "No");
            if (!confirmar) return;

            await DatabaseService.Database.DeleteVemtaHeadAsync(_comprareg);
            CargarVentas();
            FormularioVisible = false;
            VentaActual = new VentaHeadProv();
            Nuevo(false);
        }
        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }
        public void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }

        private void Nuevo(bool mostrarformulario=true)
        {
            VentaActual = new VentaHeadProv
            {
                VentaReg = new VentaHead { Fecha = DateTime.Now }, // o el valor real
                ClieDescr = "(Desconocido)"
            };
            FormularioVisible = mostrarformulario;
        }

        private async void IrADetalle()
        {
            if (VentaActual.VentaReg.Id == 0) return;

            // Usamos Shell navigation (debes tener registrada VentaDetallePage)
            await Shell.Current.GoToAsync(nameof(VentaDetallePage), true,
                new Dictionary<string, object> { { "VentaHeadId", VentaActual.VentaReg.Id } });
        }
        public ICommand ItemTappedCommand => new Command<VentaHeadProv>(item =>
        {
            VentaActual = item;
            // Otras acciones...
        });
    }
}
