﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Negocio.Views;

namespace Negocio.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        public string Usuario { get; set; }
        public string Contrasena { get; set; }
        public string Mensaje { get; set; }
        public string Email { get; set; }

        public ICommand IniciarSesionCommand { get; }
        public ICommand IrARegistroCommand { get; }
        public ICommand IrARecuperarCommand { get; }

        /*
        public LoginViewModel()
        {
            IniciarSesionCommand = new Command(async () => await IniciarSesionAsync());
            IrARegistroCommand = new Command(async () => await Shell.Current.GoToAsync(nameof(RegistroPage)));
            IrARecuperarCommand = new Command(async () => await Shell.Current.GoToAsync(nameof(RecuperarContrasenaPage)));
        }
        */
        public LoginViewModel()
        {
            IniciarSesionCommand = new Command(async () => await IniciarSesionAsync());
            IrARegistroCommand = new Command(async () =>
            {
                await Application.Current.MainPage.Navigation.PushAsync(new RegistroPage());
            });
            IrARecuperarCommand = new Command(async () =>
            {
                await Application.Current.MainPage.Navigation.PushAsync(new RecuperarContrasenaPage());
            });
        }

        /*
        private async Task IniciarSesionAsync()
        {
            var usuario = await DatabaseService.Database.GetUsuarioByEmailYContrasenaAsync(Correo, Contrasena);

            if (usuario != null)
            {
                Preferences.Set("UsuarioLogueado", true);

                // Redirigir a la página principal tras login
                await Shell.Current.GoToAsync("//InicioPage"); // O la ruta de tu primera pestaña
            }
            else
            {
                Mensaje = "Correo o contraseña incorrectos.";
                OnPropertyChanged(nameof(Mensaje));
            }
        }

        */
        
        private async Task IniciarSesionAsync()
        {
            var usuario = await DatabaseService.Database.GetUsuarioByNameYContrasena(Usuario, Contrasena);
            if (usuario != null)
            {
                // Sustituimos toda la app por el Shell con la navegación completa
                Application.Current.MainPage = new AppShell();
            }
            else
            {
                await Application.Current.MainPage.DisplayAlert("Error", "Credenciales incorrectas", "OK");
            }
        }
        

    }
}
