using System.Collections.ObjectModel;
using System.Windows.Input;
using Negocio.Models;
using System.Linq;

namespace Negocio.ViewModels
{
    public class SeleccionProveedorViewModel : BaseViewModel
    {
        private string _filtro;
        private Proveedor _proveedorSeleccionado;

        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }

        public Proveedor ProveedorSeleccionado
        {
            get => _proveedorSeleccionado;
            set => SetProperty(ref _proveedorSeleccionado, value);
        }

        public ObservableCollection<Proveedor> ProveedoresFiltrados { get; set; } = new();
        private List<Proveedor> TodosLosProveedores { get; set; } = new();

        public SeleccionProveedorViewModel()
        {
            CargarProveedores();
        }

        private async void CargarProveedores()
        {
            var lista = await DatabaseService.Database.GetProveedoresAsync();
            TodosLosProveedores = lista;
            AplicarFiltro();
        }

        private void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodosLosProveedores
                : TodosLosProveedores.Where(p =>
                    (p.Descrip?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Codigo?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            ProveedoresFiltrados.Clear();
            foreach (var proveedor in resultado)
                ProveedoresFiltrados.Add(proveedor);
        }
        public ICommand ItemTappedCommand => new Command<Proveedor>(item =>
        {
            ProveedorSeleccionado = item;
            // Otras acciones...
        });
    }
}