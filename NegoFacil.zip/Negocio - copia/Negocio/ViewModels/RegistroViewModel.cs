﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Negocio.Models;

namespace Negocio.ViewModels
{
    public class RegistroViewModel : BaseViewModel
    {
        public string Usuario { get; set; }
        public string Contrasena { get; set; }
        public string Confirmar { get; set; }
        public string Email { get; set; }
        public string Mensaje { get; set; }

        public ICommand RegistrarCommand { get; }

        public RegistroViewModel()
        {
            RegistrarCommand = new Command(async () => await RegistrarAsync());
        }

        private async Task RegistrarAsync()
        {
            if (Contrasena != Confirmar)
            {
                Mensaje = "Las contraseñas no coinciden.";
                OnPropertyChanged(nameof(Mensaje));
                return;
            }

            var existente = await DatabaseService.Database.GetUsuarioByNombreAsync(Usuario);
            if (existente != null)
            {
                Mensaje = "El usuario ya existe.";
                OnPropertyChanged(nameof(Mensaje));
                return;
            }

            await DatabaseService.Database.InsertUsuarioAsync(new Usuario
            {
                Nombre = Usuario,
                Contrasena = Contrasena,
                Email = Email
            });
            await Application.Current!.MainPage!.DisplayAlert("Registro completado", "Puedes iniciar sesión ahora.", "OK");
            await Application.Current!.MainPage!.Navigation.PopAsync();

            //await Shell.Current.DisplayAlert("Registro completado", "Puedes iniciar sesión ahora.", "OK");
            //await Shell.Current.GoToAsync(".."); // Volver al login
        }
    }
}
