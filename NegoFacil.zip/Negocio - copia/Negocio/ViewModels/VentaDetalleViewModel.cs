﻿using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using System.Windows.Input;
using Microsoft.Maui.Controls;
using Negocio.Models;
using Negocio.Views;
using Negocio.Helpers;
using ClosedXML.Excel;

using System.IO;
using Microsoft.Maui.Storage;


//using Windows.Storage.AccessCache;

namespace Negocio.ViewModels
{
    [QueryProperty(nameof(VentaHeadId), "VentaHeadId")]
    public class VentaDetalleViewModel : BaseViewModel
    {
        public bool VieneDeSeleccion { get; private set; }
        private int _ventaHeadId;
        private VentaDetProd _detalleActual = new();
        private bool _formularioVisible;

        public int VentaHeadId
        {
            get => _ventaHeadId;
            set
            {
                _ventaHeadId = value;
                if (!VieneDeSeleccion)
                {
                    CargarDetalles();
                    CargarCabecera();
                }
                VieneDeSeleccion=false;
            }
        }

        public VentaDetProd DetalleActual
        {
            get => _detalleActual;
            set
            {
                if (SetProperty(ref _detalleActual, value) && value.VentaDetReg != null)
                {
                    FormularioVisible = true;
                    ProductoSeleccionado = Productos.FirstOrDefault(p => p.Id == value.VentaDetReg.Prodid);

                }
            }
        }


        private string _clienteNombre;
        public string ClienteNombre
        {
            get => _clienteNombre;
            set => SetProperty(ref _clienteNombre, value);
        }

        private string _albaranNumero;
        public string AlbaranNumero
        {
            get => _albaranNumero;
            set => SetProperty(ref _albaranNumero, value);
        }

        private DateTime _fechaVenta;
        public DateTime FechaVenta
        {
            get => _fechaVenta;
            set => SetProperty(ref _fechaVenta, value);
        }

        private Producto _productoSeleccionado;
        public Producto ProductoSeleccionado
        {
            get => _productoSeleccionado;
            set
            {
                if (SetProperty(ref _productoSeleccionado, value) && value != null)
                {
                    DetalleActual.VentaDetReg.Prodid = value.Id;
                }
            }
        }

        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand SeleccionarProductoCommand { get; }
        public ICommand ExportarExcelCommand { get; }


        public VentaDetalleViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            NuevoCommand = new Command(Nuevo);
            CancelarCommand = new Command(Cancel);
            SeleccionarProductoCommand = new Command(SeleccionarProducto);
            ExportarExcelCommand = new Command(async () => await ExportarExcelAsync());

            CargarProductos(); // importante

        }

        private async void SeleccionarProducto()
        {
            EstadoSeleccionVenta.EstadoActual = new VentaDetallePageState
            {
                formulariovisible = this.FormularioVisible,
                detalleactual = this.DetalleActual.VentaDetReg
            };
            VieneDeSeleccion = true;
            await Shell.Current.GoToAsync(nameof(SeleccionProductoPage));
        }

        public ObservableCollection<Producto> Productos { get; set; } = new();

        private async void CargarProductos()
        {
            var lista = await DatabaseService.Database.GetProductosAsync();
            Productos.Clear();
            foreach (var item in lista)
                Productos.Add(item);
        }
        public ObservableCollection<VentaDetProd> Detalles { get; set; } = new();

        private async void CargarDetalles()
        {
            if (VentaHeadId == 0) return;

            var lista = await DatabaseService.Database.GetVentaDetsByHeadIdAsync(VentaHeadId);
            Detalles.Clear();
            foreach (var item in lista)
            {
                Producto producto = await DatabaseService.Database.GetProductoByIdAsync(item.Prodid);
                Detalles.Add(new VentaDetProd
                {
                    VentaDetReg = item,
                    ProdDescr = producto?.Descrip ?? "(Cliente desconocido)"
                });
            }
            FormularioVisible = false;
            //Atencion
            //DetalleActual = new VentaDetProd(); // reseteamos para evitar visibilidad indeseada
            Nuevo(false);
        }

        

        private async void CargarCabecera()
        {
            var cabecera = (await DatabaseService.Database.GetVentaHeadsAsync())
                            .FirstOrDefault(h => h.Id == VentaHeadId);

            if (cabecera != null)
            {
                AlbaranNumero = cabecera.Albaran;
                FechaVenta = cabecera.Fecha;

                var cliente = (await DatabaseService.Database.GetClientesAsync())
                                .FirstOrDefault(p => p.Id == cabecera.Clieid);

                ClienteNombre =  cliente?.Descrip ?? "(Desconocido)";
            }
        }

        private async void Guardar()
        {
            if (FormularioVisible)
            {
                if (DetalleActual == null) return;
                var _ventadetreg = DetalleActual.VentaDetReg;

                _ventadetreg.HeadId = VentaHeadId;

                VentaDet _ventadetoldreg = (await DatabaseService.Database.GetVentaDetByIdAsync(_ventadetreg.Id));
                decimal entrada = 0;
                if (_ventadetoldreg != null)
                {
                    entrada = _ventadetoldreg.Cantidad;
                }
                decimal salida = _ventadetreg.Cantidad;
                decimal cantidad = entrada - salida;
                int prodId = _ventadetreg.Prodid;
                if (_ventadetreg.Id == 0)
                    await DatabaseService.Database.InsertVentaDetAsync(_ventadetreg);
                else
                    await DatabaseService.Database.UpdateVentaDetAsync(_ventadetreg);
                await DatabaseService.Database.SumarStockProductoAsync(prodId, cantidad);
                CargarProductos();
                CargarDetalles();
                FormularioVisible = false;
                //Atencion
                //DetalleActual = new VentaDetProd();
                Nuevo(false);
            }
        }

        private async void Eliminar()
        {
            var _ventadetreg = DetalleActual.VentaDetReg;
            if (_ventadetreg?.Id > 0)
            {

                bool confirmar = await Shell.Current.DisplayAlert(
                    "Confirmar eliminación",
                    "¿Estás seguro de que quieres eliminar este resgistro?",
                    "Sí", "No");
                if (!confirmar) return;

                VentaDet _ventadetoldreg = (await DatabaseService.Database.GetVentaDetByIdAsync(_ventadetreg.Id));
                decimal salida = 0;
                decimal entrada = 0;
                if (_ventadetoldreg != null)
                {
                    entrada = _ventadetoldreg.Cantidad;
                }
                decimal cantidad = entrada - salida;
                int prodId = _ventadetreg.Prodid;

                await DatabaseService.Database.DeleteVentaDetAsync(_ventadetreg);
                await DatabaseService.Database.SumarStockProductoAsync(prodId, cantidad);
                CargarProductos();
                CargarDetalles();
                FormularioVisible = false;
                //Atencion
                //DetalleActual = new VentaDetProd();
                Nuevo(false);
            }
        }
        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }

        private void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }

        private void Nuevo(bool mostrarformulario = true )
        {
            DetalleActual = new VentaDetProd();
            DetalleActual.VentaDetReg = new VentaDet();
            FormularioVisible = mostrarformulario;
        }
        public ICommand ItemTappedCommand => new Command<VentaDetProd>(item =>
        {
            DetalleActual = item;
            // Otras acciones...
        });
public async Task ExportarExcelAsync()
    {
        var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add("Detalle de Venta");

        // Cabecera
        worksheet.Cell("A1").Value = "Cliente:";
        worksheet.Cell("B1").Value = ClienteNombre;
        worksheet.Cell("A2").Value = "Albarán:";
        worksheet.Cell("B2").Value = AlbaranNumero;
        worksheet.Cell("A3").Value = "Fecha:";
        worksheet.Cell("B3").Value = FechaVenta.ToString("dd/MM/yyyy");

        // Encabezados de columnas
        worksheet.Cell("A5").Value = "Producto";
        worksheet.Cell("B5").Value = "Precio";
        worksheet.Cell("C5").Value = "Cantidad";
        worksheet.Cell("D5").Value = "IVA";

        int row = 6;
        foreach (var detalle in Detalles)
        {
            var producto = Productos.FirstOrDefault(p => p.Id == detalle.VentaDetReg.Prodid);
            worksheet.Cell(row, 1).Value = producto?.Descrip ?? $"ID: {detalle.VentaDetReg.Prodid}";
            worksheet.Cell(row, 2).Value = detalle.VentaDetReg.PrecioVen;
            worksheet.Cell(row, 3).Value = detalle.VentaDetReg.Cantidad;
            worksheet.Cell(row, 4).Value = detalle.VentaDetReg.IVA ? "Sí" : "No";
            row++;
        }

        // Estilos opcionales
        worksheet.Columns().AdjustToContents();

            // Crear nombre y ruta del archivo
            var fileName = $"DetalleVenta_{AlbaranNumero}.xlsx";

#if ANDROID
            var downloadsPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
#elif WINDOWS
    var downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
#else
    var downloadsPath = FileSystem.CacheDirectory; // Fallback
#endif

            var filePath = Path.Combine(downloadsPath, fileName);


            // Guardar el archivo
            //var fileName = $"DetalleVenta_{AlbaranNumero}.xlsx";
            //var filePath = Path.Combine(FileSystem.CacheDirectory, fileName);

        workbook.SaveAs(filePath);

        // Mostrar notificación o abrir
        await Shell.Current.DisplayAlert("Exportación completada", $"Archivo guardado en:\n{filePath}", "OK");

        // Opcional: abrir o compartir el archivo
        await Share.RequestAsync(new ShareFileRequest
        {
            Title = "Compartir Excel",
            File = new ShareFile(filePath)
        });
    }

}
}
