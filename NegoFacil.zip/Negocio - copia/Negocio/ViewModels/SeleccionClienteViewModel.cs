using System.Collections.ObjectModel;
using System.Windows.Input;
using Negocio.Models;
using System.Linq;

namespace Negocio.ViewModels
{
    public class SeleccionClienteViewModel : BaseViewModel
    {
        private string _filtro;
        private Cliente _clienteSeleccionado;

        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }

        public Cliente ClienteSeleccionado
        {
            get => _clienteSeleccionado;
            set => SetProperty(ref _clienteSeleccionado, value);
        }

        public ObservableCollection<Cliente> ClientesFiltrados { get; set; } = new();
        private List<Cliente> TodosLosClientes { get; set; } = new();

        public SeleccionClienteViewModel()
        {
            CargarClientes();
        }

        private async void CargarClientes()
        {
            var lista = await DatabaseService.Database.GetClientesAsync();
            TodosLosClientes = lista;
            AplicarFiltro();
        }

        private void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodosLosClientes
                : TodosLosClientes.Where(p =>
                    (p.Descrip?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Codigo?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            ClientesFiltrados.Clear();
            foreach (var cliente in resultado)
                ClientesFiltrados.Add(cliente);
        }
        public ICommand ItemTappedCommand => new Command<Cliente>(item =>
        {
            ClienteSeleccionado = item;
            // Otras acciones...
        });
    }
}