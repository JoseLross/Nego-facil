﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ClosedXML.Excel;
using Negocio.Models;
namespace Negocio.ViewModels
{
    public class ClientesViewModel : BaseViewModel
    {
        private string _filtro;
        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }
        private Cliente _clienteActual = new Cliente();
        private bool _formularioVisible;

        public Cliente ClienteActual
        {
            get => _clienteActual;
            set
            {
                if (SetProperty(ref _clienteActual, value) && value != null)
                {
                    FormularioVisible = true;
                }
            }
        }

        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }

        public ObservableCollection<Cliente> Clientes { get; set; } = new();

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand ExportarCommand { get; }

        public ClientesViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            NuevoCommand = new Command(Nuevo);
            CancelarCommand = new Command(Cancel);
            ExportarCommand = new Command(async () => await ExportarClientesAsync());
            CargarClientes();
        }

        private async void CargarClientes()
        {
            /*
            var lista = await DatabaseService.Database.GetClientesAsync();
            Clientes.Clear();
            foreach (var item in lista)
                Clientes.Add(item);
        */
            var lista2 = await DatabaseService.Database.GetClientesAsync();
            TodosLosClientes = lista2;
            AplicarFiltro();
        }
        private List<Cliente> TodosLosClientes { get; set; } = new();

        private void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodosLosClientes
                : TodosLosClientes.Where(p =>
                    (p.Descrip?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Codigo?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            Clientes.Clear();
            foreach (var cliente in resultado)
                Clientes.Add(cliente);
        }

        private async void Guardar()
        {
            if (FormularioVisible)
            {
                if (ClienteActual.Id == 0)
                    await DatabaseService.Database.InsertClienteAsync(ClienteActual);
                else
                    await DatabaseService.Database.UpdateClienteAsync(ClienteActual);

                CargarClientes();
                FormularioVisible = false;
                Nuevo(false); // También podrías omitirlo si quieres limpiar solo cuando se pulsa "Nuevo"
            }
        }

        private async void Eliminar()
        {
            if (ClienteActual.Id == 0) return;

            bool confirmar = await Shell.Current.DisplayAlert(
                "Confirmar eliminación",
                "¿Estás seguro de que quieres eliminar este cliente?",
                "Sí", "No");
            if (!confirmar) return;

            await DatabaseService.Database.DeleteClienteAsync(ClienteActual);
            CargarClientes();
            FormularioVisible = false;
            Nuevo(false);
        }
        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }
        public void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }

        private void Nuevo(bool  mostrarformulario=true)
        {
            ClienteActual = new Cliente();
            FormularioVisible = mostrarformulario;
        }
        public ICommand ItemTappedCommand => new Command<Cliente>(item =>
        {
            ClienteActual = item;
            // Otras acciones...
        });
        public async Task ExportarClientesAsync()
        {
            var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add("Clientes");

            // Cabecera
            worksheet.Cell("A1").Value = "LISTADO DE CLIENTES";
            worksheet.Cell("A1").Style.Font.Bold = true;
            worksheet.Range("A1:H1").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

            // Encabezado de columnas
            worksheet.Cell("A2").Value = "Código";
            worksheet.Cell("B2").Value = "Descripción";
            worksheet.Cell("C2").Value = "Teléfono";
            worksheet.Cell("D2").Value = "Dirección 1";
            worksheet.Cell("E2").Value = "Dirección 2";
            worksheet.Cell("F2").Value = "Ciudad";
            worksheet.Cell("G2").Value = "País";

            int row = 3;

            foreach (var cliente in Clientes)
            {
                worksheet.Cell(row, 1).Value = cliente.Codigo;
                worksheet.Cell(row, 2).Value = cliente.Descrip;
                worksheet.Cell(row, 3).Value = cliente.Telef;
                worksheet.Cell(row, 4).Value = cliente.Direc1;
                worksheet.Cell(row, 5).Value = cliente.Direc2;
                worksheet.Cell(row, 6).Value = cliente.Ciudad;
                worksheet.Cell(row, 7).Value = cliente.Pais;
                row++;
            }

            worksheet.Columns().AdjustToContents();

            var fileName = "ListadoClientes.xlsx";

#if ANDROID
            var downloadsPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
#elif WINDOWS
    var downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
#else
    var downloadsPath = FileSystem.CacheDirectory; // Fallback
#endif

            var filePath = Path.Combine(downloadsPath, fileName);

            // Guardar archivo
            workbook.SaveAs(filePath);

            await Shell.Current.DisplayAlert("Exportación completada", $"Archivo guardado en:\n{filePath}", "OK");

            await Share.RequestAsync(new ShareFileRequest
            {
                Title = "Compartir Excel",
                File = new ShareFile(filePath)
            });
        }
    }
}
