﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using ClosedXML.Excel;
using Negocio.Models;

namespace Negocio.ViewModels
{
    public class ProductosViewModel : BaseViewModel
    {
        private string _filtro;
        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }
        private Producto _productoActual = new Producto();
        public Producto ProductoActual
        {
            get => _productoActual;
            set
            {
                if (SetProperty(ref _productoActual, value) && value != null)
                {
                    FormularioVisible = true;
                }
            }
        }

        public ObservableCollection<Producto> Productos { get; set; } = new();

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand ExportarCommand { get; }

        public ProductosViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            NuevoCommand = new Command(Nuevo);
            CancelarCommand = new Command(Cancel);
            ExportarCommand = new Command(async () => await ExportarProductosAsync());
            CargarProductos();
        }

        public  async void CargarProductos()
        {
            /*
            var lista = await DatabaseService.Database.GetProductosAsync();
            Productos.Clear();
            foreach (var item in lista)
                Productos.Add(item);
            */
            var lista2 = await DatabaseService.Database.GetProductosAsync();
            TodosLosProductos = lista2;
            AplicarFiltro();
        }
        private List<Producto> TodosLosProductos { get; set; } = new();

        private void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodosLosProductos
                : TodosLosProductos.Where(p =>
                    (p.Descrip?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Refer?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            Productos.Clear();
            foreach (var producto in resultado)
                Productos.Add(producto);
        }

        private async void Guardar()
        {
            if (FormularioVisible)
            {
                if (ProductoActual.Id == 0)
                    await DatabaseService.Database.InsertProductoAsync(ProductoActual);
                else
                    await DatabaseService.Database.UpdateProductoAsync(ProductoActual);

                CargarProductos();
                FormularioVisible = false;
                Nuevo(false);
            }
        }

        private async void Eliminar()
        {
            if (ProductoActual.Id == 0) return;

            bool confirmar = await Shell.Current.DisplayAlert(
                "Confirmar eliminación",
                "¿Estás seguro de que quieres eliminar este producto?",
                "Sí", "No");
            if (!confirmar) return;

            await DatabaseService.Database.DeleteProductoAsync(ProductoActual);
            CargarProductos();
            FormularioVisible = false;
            Nuevo(false);
        }
        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }

        public void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }
        private void Nuevo(bool mostrarformulario = true)
        {
            ProductoActual = new Producto();
            FormularioVisible = mostrarformulario;
        }
        private bool _formularioVisible;
        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }
        public ICommand ItemTappedCommand => new Command<Producto>(item =>
        {
            ProductoActual = item;
            // Otras acciones...
        });
        public async Task ExportarProductosAsync()
        {
            var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add("Productos");

            // Cabecera
            worksheet.Cell("A1").Value = "LISTADO DE PRODUCTOS";
            worksheet.Cell("A1").Style.Font.Bold = true;
            worksheet.Range("A1:H1").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

            // Encabezado de columnas
            worksheet.Cell("A2").Value = "Referencia";
            worksheet.Cell("B2").Value = "Descripción";
            worksheet.Cell("C2").Value = "Un.Medida";
            worksheet.Cell("D2").Value = "Stock";

            int row = 3;

            foreach (var producto in Productos)
            {
                worksheet.Cell(row, 1).Value = producto.Refer;
                worksheet.Cell(row, 2).Value = producto.Descrip;
                worksheet.Cell(row, 3).Value = producto.UMed;
                worksheet.Cell(row, 4).Value = producto.Stock;
                row++;
            }

            worksheet.Columns().AdjustToContents();

            var fileName = "ListadoProductos.xlsx";

#if ANDROID
            var downloadsPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
#elif WINDOWS
    var downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
#else
    var downloadsPath = FileSystem.CacheDirectory; // Fallback
#endif

            var filePath = Path.Combine(downloadsPath, fileName);

            // Guardar archivo
            workbook.SaveAs(filePath);

            await Shell.Current.DisplayAlert("Exportación completada", $"Archivo guardado en:\n{filePath}", "OK");

            await Share.RequestAsync(new ShareFileRequest
            {
                Title = "Compartir Excel",
                File = new ShareFile(filePath)
            });
        }
    }
}

