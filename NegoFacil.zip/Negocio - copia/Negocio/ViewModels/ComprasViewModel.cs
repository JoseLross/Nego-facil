﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using Negocio.Models;
using Negocio.Views;
using Microsoft.Maui.Controls;

namespace Negocio.ViewModels
{
    public class ComprasViewModel : BaseViewModel
    {
        private string _filtro;
        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }

        private CompraHeadProv _compraActual = new();
        private bool _formularioVisible;

        /*
        public CompraHeadProv CompraActual
        {
            get => _compraActual;
            set 
            {
                if (SetProperty(ref _compraActual, value) && value?.CompraReg != null)
                {
                    FormularioVisible = true;
                    ProveedorSeleccionado = Proveedores.FirstOrDefault(p => p.Id == value.CompraReg.Provid);

                }
            }
        }
        */
        private string _mensajeDebug;
        public string MensajeDebug
        {
            get => _mensajeDebug;
            set => SetProperty(ref _mensajeDebug, value);
        }
        public CompraHeadProv CompraActual
        {
            get => _compraActual;
            set
            {
                if (SetProperty(ref _compraActual, value) && value?.CompraReg != null)
                //if (SetProperty(ref _compraActual, value) && value != null)
                {
                    FormularioVisible = true;

                    // ✅ Protección extra: evita error si Proveedores aún no está cargado
                    //ProveedorSeleccionado = Proveedores?.FirstOrDefault(p => p.Id == value.CompraReg.Provid);
                    // 🛡️ Protección: comprueba que Proveedores no sea null ni esté vacío
                    if (Proveedores != null && Proveedores.Any())
                        ProveedorSeleccionado = Proveedores.FirstOrDefault(p => p.Id == value.CompraReg.Provid);
                    else
                        Debug.WriteLine("⚠️ Lista de proveedores vacía al intentar seleccionar");
                }
            }
        }







        private Proveedor _proveedorSeleccionado;
        public Proveedor ProveedorSeleccionado
        {
            get => _proveedorSeleccionado;
            set
            {
                if (SetProperty(ref _proveedorSeleccionado, value) && value != null)
                {
                    CompraActual.CompraReg.Provid = value.Id;
                }
            }
        }

        public ObservableCollection<Proveedor> Proveedores { get; set; } = new();

        private async void CargarProveedores()
        {
            try
            {
                var lista = await DatabaseService.Database.GetProveedoresAsync();
                Proveedores.Clear();
                foreach (var item in lista)
                    Proveedores.Add(item);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("❌ Error al cargar proveedores: " + ex.Message);
            }
        }

        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand IrADetalleCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand SeleccionarProveedorCommand { get; }


        public ComprasViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            NuevoCommand = new Command(Nuevo);
            IrADetalleCommand = new Command(IrADetalle);
            CancelarCommand = new Command(Cancel);
            SeleccionarProveedorCommand = new Command(SeleccionarProveedor);

            CargarProveedores();
            CargarCompras();
        }

        
        private async void SeleccionarProveedor()
        {
            await Shell.Current.GoToAsync(nameof(SeleccionProveedorPage));
        }
        
        /*
        private async void SeleccionarProveedor()
        {
            EstadoSeleccionProveedor.Callback = (proveedor) =>
            {
                if (proveedor != null)
                    ProveedorSeleccionado = proveedor;
            };

            await Shell.Current.GoToAsync(nameof(SeleccionProveedorPage));
        }
        */
        public ObservableCollection<CompraHeadProv> Compras { get; set; } = new();
        private async void CargarCompras()
        {
            /*
            try
            {
                var lista = await DatabaseService.Database.GetCompraHeadsAsync();
                Compras.Clear();
                foreach (var item in lista)
                {
                    var proveedor = await DatabaseService.Database.GetProveedorByIdAsync(item.Provid);
                    Compras.Add(new CompraHeadProv
                    {
                        CompraReg = item,
                        ProvDescr = proveedor?.Descrip ?? "(Desconocido)"
                    });
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("❌ Error al cargar compras: " + ex.Message);
            }
            */
            var lista2 = await DatabaseService.Database.GetCompraHeadsAsync();
            TodasLasCompras = lista2;
            AplicarFiltro();
        }


        private List<CompraHead> TodasLasCompras { get; set; } = new();

        private async void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodasLasCompras
                : TodasLasCompras.Where(p =>
                    (p.Albaran?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Albaran?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            Compras.Clear();
            foreach (var item in resultado)
            {
                var proveedor = await DatabaseService.Database.GetProveedorByIdAsync(item.Provid);
                Compras.Add(new CompraHeadProv
                {
                    CompraReg = item,
                    ProvDescr = proveedor?.Descrip ?? "(Desconocido)"
                });
            }
        }


        /*
        private async void Guardar()
        {
            if (FormularioVisible)
            {
                var _comprareg = CompraActual.CompraReg;
                if (_comprareg.Id == 0)
                    await DatabaseService.Database.InsertCompraHeadAsync(_comprareg);
                else
                    await DatabaseService.Database.UpdateCompraHeadAsync(_comprareg);

                CargarCompras();
                FormularioVisible = false;
                CompraActual = new CompraHeadProv();
                Nuevo(false);
            }
        }
        */

        private async void Guardar()
        {
            try
            {
                if (CompraActual == null || ProveedorSeleccionado == null) return;

                CompraActual.CompraReg.Provid = ProveedorSeleccionado.Id;

                if (CompraActual.CompraReg.Id == 0)
                    await DatabaseService.Database.InsertCompraHeadAsync(CompraActual.CompraReg);
                else
                    await DatabaseService.Database.UpdateCompraHeadAsync(CompraActual.CompraReg);

                CargarCompras();
                Nuevo(false);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("❌ Error al guardar: " + ex.Message);
            }
        }

        /*
        private async void Eliminar()
        {
            var _comprareg = CompraActual.CompraReg;
            if (_comprareg.Id == 0) return;
            await DatabaseService.Database.DeleteCompraHeadAsync(_comprareg);
            CargarCompras();
            FormularioVisible = false;
            CompraActual = new CompraHeadProv();
            Nuevo(false);
        }
        */
        private async void Eliminar()
        {
            try
            {
                if (CompraActual?.CompraReg.Id > 0)
                {

                    bool confirmar = await Shell.Current.DisplayAlert(
                        "Confirmar eliminación",
                        "¿Estás seguro de que quieres eliminar esta compra?",
                        "Sí", "No");
                    if (!confirmar) return;

                    await DatabaseService.Database.DeleteCompraHeadAsync(CompraActual.CompraReg);
                    CargarCompras();
                    Nuevo(false);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("❌ Error al eliminar: " + ex.Message);
            }
        }

        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }
        public void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }

        /*
        private void Nuevo(bool mostrarformulario=true)
        {
            //CompraActual = new CompraHeadProv(); //{ CompraReg.Fecha = DateTime.Now };
            CompraActual = new CompraHeadProv
            {
                CompraReg = new CompraHead { Fecha = DateTime.Now }, // o el valor real
                ProvDescr = "(Desconocido)"
            };

            FormularioVisible = mostrarformulario;
        }
        */
        private void Nuevo(bool mostrar = true)
        {
            CompraActual = new CompraHeadProv
            {
                CompraReg = new CompraHead()
            };
            ProveedorSeleccionado = null;
            FormularioVisible = mostrar;
        }


        /*
        private async void IrADetalle()
        {
            if (CompraActual.CompraReg.Id == 0) return;

            // Usamos Shell navigation (debes tener registrada CompraDetallePage)
            await Shell.Current.GoToAsync(nameof(CompraDetallePage), true,
                new Dictionary<string, object> { { "CompraHeadId", CompraActual.CompraReg.Id } });
        }
        */

        private async void IrADetalle()
        {
            if (CompraActual?.CompraReg.Id > 0)
            {
                await Shell.Current.GoToAsync($"{nameof(CompraDetallePage)}?CompraHeadId={CompraActual.CompraReg.Id}");
            }
        }

        public ICommand ItemTappedCommand => new Command<CompraHeadProv>(item =>
        {
            CompraActual = item;
            // Otras acciones...
        });
    }
}
