﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using ClosedXML.Excel;
using Negocio.Models;

using System.IO;
using Microsoft.Maui.Storage;
using System.Runtime.InteropServices;
using System.Threading.Tasks;


namespace Negocio.ViewModels
{
    public class ProveedoresViewModel : BaseViewModel
    {
        private string _filtro;
        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                {
                    AplicarFiltro();
                }
            }
        }
        private Proveedor _proveedorActual = new Proveedor();
        public Proveedor ProveedorActual
        {
            get => _proveedorActual;
            set
            {
                if (SetProperty(ref _proveedorActual, value) && value != null)
                {
                    FormularioVisible = true;
                }
            }
        }

        public ObservableCollection<Proveedor> Proveedores { get; set; } = new();

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand ExportarCommand { get; }
        public ProveedoresViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            CancelarCommand = new Command(Cancel);
            NuevoCommand = new Command(Nuevo);
            ExportarCommand = new Command(async () => await ExportarProveedoresAsync());
            CargarProveedores();
        }

        private async void CargarProveedores()
        {
            /*
            var lista = await DatabaseService.Database.GetProveedoresAsync();
            Proveedores.Clear();
            foreach (var item in lista)
                Proveedores.Add(item);
            */
            var lista2 = await DatabaseService.Database.GetProveedoresAsync();
            TodosLosProveedores = lista2;
            AplicarFiltro();

        }

        private List<Proveedor> TodosLosProveedores { get; set; } = new();

        private void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodosLosProveedores
                : TodosLosProveedores.Where(p =>
                    (p.Descrip?.ToLower().Contains(Filtro.ToLower()) ?? false) ||
                    (p.Codigo?.ToLower().Contains(Filtro.ToLower()) ?? false)).ToList();

            Proveedores.Clear();
            foreach (var proveedor in resultado)
                Proveedores.Add(proveedor);
        }

        private async void Guardar()
        {
            if (FormularioVisible)
            {
                if (ProveedorActual.Id == 0)
                    await DatabaseService.Database.InsertProveedorAsync(ProveedorActual);
                else
                    await DatabaseService.Database.UpdateProveedorAsync(ProveedorActual);

                CargarProveedores();
                FormularioVisible = false;
                Nuevo(false);
            }
        }

        private async void Eliminar()
        {
            if (ProveedorActual.Id == 0) return;

            bool confirmar = await Shell.Current.DisplayAlert(
                "Confirmar eliminación",
                "¿Estás seguro de que quieres eliminar este proveedor?",
                "Sí", "No");
            if (!confirmar) return;

            await DatabaseService.Database.DeleteProveedorAsync(ProveedorActual);
            CargarProveedores();
            FormularioVisible = false;
            Nuevo(false);
        }
        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }
        public void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }

        private void Nuevo(bool mostrarformulario = true)
        {
            ProveedorActual = new Proveedor();
            FormularioVisible = mostrarformulario;
        }
        private bool _formularioVisible;
        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }
        public ICommand ItemTappedCommand => new Command<Proveedor>(item =>
        {
            ProveedorActual = item;
            // Otras acciones...
        });

public async Task ExportarProveedoresAsync()
    {
        var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add("Proveedores");

        // Cabecera
        worksheet.Cell("A1").Value = "LISTADO DE PROVEEDORES";
        worksheet.Cell("A1").Style.Font.Bold = true;
        worksheet.Range("A1:H1").Merge().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

        // Encabezado de columnas
        worksheet.Cell("A2").Value = "Código";
        worksheet.Cell("B2").Value = "Descripción";
        worksheet.Cell("C2").Value = "Teléfono";
        worksheet.Cell("D2").Value = "Dirección 1";
        worksheet.Cell("E2").Value = "Dirección 2";
        worksheet.Cell("F2").Value = "Ciudad";
        worksheet.Cell("G2").Value = "País";

        int row = 3;

        foreach (var proveedor in Proveedores)
        {
            worksheet.Cell(row, 1).Value = proveedor.Codigo;
            worksheet.Cell(row, 2).Value = proveedor.Descrip;
            worksheet.Cell(row, 3).Value = proveedor.Telef;
            worksheet.Cell(row, 4).Value = proveedor.Direc1;
            worksheet.Cell(row, 5).Value = proveedor.Direc2;
            worksheet.Cell(row, 6).Value = proveedor.Ciudad;
            worksheet.Cell(row, 7).Value = proveedor.Pais;
            row++;
        }

        worksheet.Columns().AdjustToContents();

        var fileName = "ListadoProveedores.xlsx";

#if ANDROID
        var downloadsPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
#elif WINDOWS
    var downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
#else
    var downloadsPath = FileSystem.CacheDirectory; // Fallback
#endif

        var filePath = Path.Combine(downloadsPath, fileName);

        // Guardar archivo
        workbook.SaveAs(filePath);

        await Shell.Current.DisplayAlert("Exportación completada", $"Archivo guardado en:\n{filePath}", "OK");

        await Share.RequestAsync(new ShareFileRequest
        {
            Title = "Compartir Excel",
            File = new ShareFile(filePath)
        });
    }

}
}

