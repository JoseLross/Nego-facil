using System.Collections.ObjectModel;
using System.Linq;
using Negocio.Models;
using Negocio.Helpers;
using System.Windows.Input;

namespace Negocio.ViewModels
{
    public class SeleccionProductoViewModel : BaseViewModel
    {
        private string _filtro;
        public string Filtro
        {
            get => _filtro;
            set
            {
                if (SetProperty(ref _filtro, value))
                    AplicarFiltro();
            }
        }

        public ObservableCollection<Producto> ProductosFiltrados { get; set; } = new();
        private List<Producto> TodosLosProductos { get; set; } = new();

        public SeleccionProductoViewModel()
        {
            CargarProductos();
        }

        private async void CargarProductos()
        {
            var lista = await DatabaseService.Database.GetProductosAsync();
            TodosLosProductos = lista;
            AplicarFiltro();
        }

        private void AplicarFiltro()
        {
            var resultado = string.IsNullOrWhiteSpace(Filtro)
                ? TodosLosProductos
                : TodosLosProductos.Where(p =>
                    p.Descrip?.ToLower().Contains(Filtro.ToLower()) == true ||
                    p.Refer?.ToLower().Contains(Filtro.ToLower()) == true).ToList();

            ProductosFiltrados.Clear();
            foreach (var p in resultado)
                ProductosFiltrados.Add(p);
        }
        private Producto _productoSeleccionado;
        public Producto ProductoSeleccionado
        {
            get => _productoSeleccionado;
            set => SetProperty(ref _productoSeleccionado, value);
        }
        private async void regresa()
        {
            await Shell.Current.GoToAsync("..");

        }
        public  ICommand ItemTappedCommand => new Command<Producto>(item =>
        {
            ProductoSeleccionado = item;
            // Otras acciones...
            EstadoSeleccionProducto.ProductoSeleccionado = item;
            regresa();
            //await Shell.Current.GoToAsync("..");

        });
    }
}