﻿using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using System.Windows.Input;
using Microsoft.Maui.Controls;
using Negocio.Models;
using Negocio.Views;
using Negocio.Helpers;
using ClosedXML.Excel;

//using Windows.Storage.AccessCache;

namespace Negocio.ViewModels
{
    [QueryProperty(nameof(CompraHeadId), "CompraHeadId")]
    public class CompraDetalleViewModel : BaseViewModel
    {
        public bool VieneDeSeleccion { get; private set; }
        private int _compraHeadId;
        private CompraDetProd _detalleActual = new();
        private bool _formularioVisible;

        public int CompraHeadId
        {
            get => _compraHeadId;
            set
            {
                _compraHeadId = value;
                if (!VieneDeSeleccion)
                {
                    CargarDetalles();
                    CargarCabecera();
                }
                VieneDeSeleccion=false;
            }
        }

        public CompraDetProd DetalleActual
        {
            get => _detalleActual;
            set
            {
                if (SetProperty(ref _detalleActual, value) && value.CompraDetReg != null)
                {
                    FormularioVisible = true;
                    ProductoSeleccionado = Productos.FirstOrDefault(p => p.Id == value.CompraDetReg.Prodid);

                }
            }
        }


        private string _proveedorNombre;
        public string ProveedorNombre
        {
            get => _proveedorNombre;
            set => SetProperty(ref _proveedorNombre, value);
        }

        private string _albaranNumero;
        public string AlbaranNumero
        {
            get => _albaranNumero;
            set => SetProperty(ref _albaranNumero, value);
        }

        private DateTime _fechaCompra;
        public DateTime FechaCompra
        {
            get => _fechaCompra;
            set => SetProperty(ref _fechaCompra, value);
        }

        private Producto _productoSeleccionado;
        public Producto ProductoSeleccionado
        {
            get => _productoSeleccionado;
            set
            {
                if (SetProperty(ref _productoSeleccionado, value) && value != null)
                {
                    DetalleActual.CompraDetReg.Prodid = value.Id;
                }
            }
        }

        public bool FormularioVisible
        {
            get => _formularioVisible;
            set => SetProperty(ref _formularioVisible, value);
        }

        public ICommand GuardarCommand { get; }
        public ICommand EliminarCommand { get; }
        public ICommand NuevoCommand { get; }
        public ICommand CancelarCommand { get; }
        public ICommand SeleccionarProductoCommand { get; }
        public ICommand ExportarExcelCommand { get; }


        public CompraDetalleViewModel()
        {
            GuardarCommand = new Command(Guardar);
            EliminarCommand = new Command(Eliminar);
            NuevoCommand = new Command(Nuevo);
            CancelarCommand = new Command(Cancel);
            SeleccionarProductoCommand = new Command(SeleccionarProducto);
            ExportarExcelCommand = new Command(async () => await ExportarExcelAsync());

            CargarProductos(); // importante

        }

        private async void SeleccionarProducto()
        {
            EstadoSeleccionCompra.EstadoActual = new CompraDetallePageState
            {
                formulariovisible = this.FormularioVisible,
                detalleactual = this.DetalleActual.CompraDetReg
            };
            VieneDeSeleccion = true;
            await Shell.Current.GoToAsync(nameof(SeleccionProductoPage));
        }

        public ObservableCollection<Producto> Productos { get; set; } = new();

        private async void CargarProductos()
        {
            var lista = await DatabaseService.Database.GetProductosAsync();
            Productos.Clear();
            foreach (var item in lista)
                Productos.Add(item);
        }
        public ObservableCollection<CompraDetProd> Detalles { get; set; } = new();

        private async void CargarDetalles()
        {
            if (CompraHeadId == 0) return;

            var lista = await DatabaseService.Database.GetCompraDetsByHeadIdAsync(CompraHeadId);
            Detalles.Clear();
            foreach (var item in lista)
            {
                Producto producto = await DatabaseService.Database.GetProductoByIdAsync(item.Prodid);
                Detalles.Add(new CompraDetProd
                {
                    CompraDetReg = item,
                    ProdDescr = producto?.Descrip ?? "(Proveedor desconocido)"
                });
            }
            FormularioVisible = false;
            //Atencion
            //DetalleActual = new CompraDetProd(); // reseteamos para evitar visibilidad indeseada
            Nuevo(false);
        }

        

        private async void CargarCabecera()
        {
            var cabecera = (await DatabaseService.Database.GetCompraHeadsAsync())
                            .FirstOrDefault(h => h.Id == CompraHeadId);

            if (cabecera != null)
            {
                AlbaranNumero = cabecera.Albaran;
                FechaCompra = cabecera.Fecha;

                var proveedor = (await DatabaseService.Database.GetProveedoresAsync())
                                .FirstOrDefault(p => p.Id == cabecera.Provid);

                ProveedorNombre =  proveedor?.Descrip ?? "(Desconocido)";
            }
        }

        private async void Guardar()
        {
            if (FormularioVisible)
            {
                if (DetalleActual == null) return;
                var _compradetreg = DetalleActual.CompraDetReg;

                _compradetreg.HeadId = CompraHeadId;

                CompraDet _compradetoldreg = (await DatabaseService.Database.GetCompraDetByIdAsync(_compradetreg.Id));
                decimal salida = 0;
                if (_compradetoldreg != null)
                {
                    salida = _compradetoldreg.Cantidad;
                }
                decimal entrada = _compradetreg.Cantidad;
                decimal cantidad = entrada - salida;
                int prodId = _compradetreg.Prodid;
                if (_compradetreg.Id == 0)
                    await DatabaseService.Database.InsertCompraDetAsync(_compradetreg);
                else
                    await DatabaseService.Database.UpdateCompraDetAsync(_compradetreg);
                await DatabaseService.Database.SumarStockProductoAsync(prodId, cantidad);
                CargarDetalles();
                FormularioVisible = false;
                //Atencion
                //DetalleActual = new CompraDetProd();
                Nuevo(false);
            }
        }

        private async void Eliminar()
        {
            var _compradetreg = DetalleActual.CompraDetReg;
            if (_compradetreg?.Id > 0)
            {

                bool confirmar = await Shell.Current.DisplayAlert(
                    "Confirmar eliminación",
                    "¿Estás seguro de que quieres eliminar este registro?",
                    "Sí", "No");
                if (!confirmar) return;

                CompraDet _compradetoldreg = (await DatabaseService.Database.GetCompraDetByIdAsync(_compradetreg.Id));
                decimal salida = 0;
                decimal entrada = 0;
                if (_compradetoldreg != null)
                {
                    salida = _compradetoldreg.Cantidad;
                }
                decimal cantidad = entrada - salida;
                int prodId = _compradetreg.Prodid;

                await DatabaseService.Database.DeleteCompraDetAsync(_compradetreg);
                await DatabaseService.Database.SumarStockProductoAsync(prodId, cantidad);
                CargarDetalles();
                FormularioVisible = false;
                //Atencion
                //DetalleActual = new CompraDetProd();
                Nuevo(false);
            }
        }
        public void Cancel()
        {
            Nuevo(false); // Llama al que acepta parámetro
        }

        private void Nuevo()
        {
            Nuevo(true); // Llama al que acepta parámetro
        }

        private void Nuevo(bool mostrarformulario = true )
        {
            DetalleActual = new CompraDetProd();
            DetalleActual.CompraDetReg = new CompraDet();
            FormularioVisible = mostrarformulario;
        }
        public ICommand ItemTappedCommand => new Command<CompraDetProd>(item =>
        {
            DetalleActual = item;
            // Otras acciones...
        });
        public async Task ExportarExcelAsync()
        {
            var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add("Detalle de Compra");

            // Cabecera
            worksheet.Cell("A1").Value = "Proveedor:";
            worksheet.Cell("B1").Value = ProveedorNombre;
            worksheet.Cell("A2").Value = "Albarán:";
            worksheet.Cell("B2").Value = AlbaranNumero;
            worksheet.Cell("A3").Value = "Fecha:";
            worksheet.Cell("B3").Value = FechaCompra.ToString("dd/MM/yyyy");

            // Encabezados de columnas
            worksheet.Cell("A5").Value = "Producto";
            worksheet.Cell("B5").Value = "Precio";
            worksheet.Cell("C5").Value = "Cantidad";
            worksheet.Cell("D5").Value = "IVA";

            int row = 6;
            foreach (var detalle in Detalles)
            {
                var producto = Productos.FirstOrDefault(p => p.Id == detalle.CompraDetReg.Prodid);
                worksheet.Cell(row, 1).Value = producto?.Descrip ?? $"ID: {detalle.CompraDetReg.Prodid}";
                worksheet.Cell(row, 2).Value = detalle.CompraDetReg.PrecioCom;
                worksheet.Cell(row, 3).Value = detalle.CompraDetReg.Cantidad;
                worksheet.Cell(row, 4).Value = detalle.CompraDetReg.IVA ? "Sí" : "No";
                row++;
            }

            // Estilos opcionales
            worksheet.Columns().AdjustToContents();

            // Crear nombre y ruta del archivo
            var fileName = $"DetalleCompra_{AlbaranNumero}.xlsx";

#if ANDROID
            var downloadsPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
#elif WINDOWS
    var downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
#else
    var downloadsPath = FileSystem.CacheDirectory; // Fallback
#endif

            var filePath = Path.Combine(downloadsPath, fileName);


            // Guardar el archivo
            //var fileName = $"DetalleVenta_{AlbaranNumero}.xlsx";
            //var filePath = Path.Combine(FileSystem.CacheDirectory, fileName);

            workbook.SaveAs(filePath);

            // Mostrar notificación o abrir
            await Shell.Current.DisplayAlert("Exportación completada", $"Archivo guardado en:\n{filePath}", "OK");

            // Opcional: abrir o compartir el archivo
            await Share.RequestAsync(new ShareFileRequest
            {
                Title = "Compartir Excel",
                File = new ShareFile(filePath)
            });
        }
    }

}
