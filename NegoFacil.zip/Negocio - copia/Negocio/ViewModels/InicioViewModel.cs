﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using ClosedXML.Excel;
using Negocio.Models;
using Negocio.Views;
namespace Negocio.ViewModels
{
    public class InicioViewModel : BaseViewModel
        {
        public ICommand LogoffCommand { get; }

        public InicioViewModel()
        {
            LogoffCommand = new Command(RealizarLogoff);
        }
        private void RealizarLogoff()
        {
            // Volvemos al login
            Application.Current.MainPage = new NavigationPage(new LoginPage());
        }


    }
}
