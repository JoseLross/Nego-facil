﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Negocio.ViewModels
{
    public class RecuperarContrasenaViewModel : BaseViewModel
    {
        public string Email { get; set; }
        public string Mensaje { get; set; }
        public ICommand RecuperarCommand { get; }

        public RecuperarContrasenaViewModel()
        {
            RecuperarCommand = new Command(async () => await RecuperarAsync());
        }

        private async Task RecuperarAsync()
        {
            var usuario = await DatabaseService.Database.GetUsuarioByEmailAsync(Email);
            if (usuario != null)
            {
                Mensaje = $"Tu contraseña es: {usuario.Contrasena}";
            }
            else
            {
                Mensaje = "No se encontró ningún usuario con ese email.";
            }
            OnPropertyChanged(nameof(Mensaje));
        }
    }
}
