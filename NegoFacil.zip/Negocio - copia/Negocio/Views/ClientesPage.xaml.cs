using Negocio.ViewModels;
namespace Negocio.Views;
using Negocio.Models;

public partial class ClientesPage : ContentPage
{
	public ClientesPage()
	{
		InitializeComponent();
	}
    private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (sender is CollectionView collectionView)
        {
            var viewModel = (ClientesViewModel)BindingContext;
            viewModel.ClienteActual = collectionView.SelectedItem as Cliente;
        }
    }
}