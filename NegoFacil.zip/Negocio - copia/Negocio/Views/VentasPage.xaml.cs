using Negocio.Helpers;
using Negocio.ViewModels;
namespace Negocio.Views;

public partial class VentasPage : ContentPage
{
	public VentasPage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();

        var cliente = ClienteSeleccionadoResult.Cliente;
        if (cliente != null && BindingContext is VentasViewModel vm)
        {
            vm.ClienteSeleccionado = cliente;
            vm.VentaActual.VentaReg.Clieid = cliente.Id;

            // Limpia el valor almacenado
            ClienteSeleccionadoResult.Cliente = null;
        }
    }

}