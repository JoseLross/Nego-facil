using Negocio.ViewModels;
namespace Negocio.Views;

public partial class RecuperarContrasenaPage : ContentPage
{
    public RecuperarContrasenaPage()
    {
        InitializeComponent();
        BindingContext = new RecuperarContrasenaViewModel();
    }
}