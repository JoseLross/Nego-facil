using Negocio.Helpers;
using Negocio.ViewModels;
namespace Negocio.Views;

public partial class ComprasPage : ContentPage
{
	public ComprasPage()
	{
		InitializeComponent();
	}
	
    protected override void OnAppearing()
    {
        base.OnAppearing();

        var proveedor = ProveedorSeleccionadoResult.Proveedor;
        if (proveedor != null && BindingContext is ComprasViewModel vm)
        {
            vm.ProveedorSeleccionado = proveedor;
            vm.CompraActual.CompraReg.Provid = proveedor.Id;

            // Limpia el valor almacenado
         ProveedorSeleccionadoResult.Proveedor = null;
        }
    }

}