using Negocio.ViewModels;
namespace Negocio.Views;

public partial class RegistroPage : ContentPage
{
    public RegistroPage()
    {
        InitializeComponent();
        BindingContext = new RegistroViewModel();
    }
}