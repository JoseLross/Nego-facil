using Negocio.Helpers;
using Negocio.Models;

namespace Negocio.Views
{
    public partial class SeleccionClientePage : ContentPage
    {
        public SeleccionClientePage()
        {
            InitializeComponent();
        }

        private async void OnClienteSeleccionado(object sender, SelectionChangedEventArgs e)
        {
            if (e.CurrentSelection.FirstOrDefault() is Cliente cliente)
            {
                ClienteSeleccionadoResult.Cliente = cliente;
                await Shell.Current.GoToAsync(".."); // volver a la p�gina anterior
            }
        }

        private async void OnCancelarClicked(object sender, EventArgs e)
        {
            ClienteSeleccionadoResult.Cliente = null;
            await Shell.Current.GoToAsync(".."); // volver sin seleccionar
        }
    }
}
