using Negocio.Helpers;
using Negocio.ViewModels;
namespace Negocio.Views;
using Negocio.ViewModels;

public partial class VentaDetallePage : ContentPage
{
    public VentaDetallePage()
    {
        InitializeComponent();
    }
    protected override void OnAppearing()
    {
        base.OnAppearing();

        //var savedState = EstadoSeleccionProducto.Instance.GetPageState<CompraDetallePage, CompraDetalletPageState>();
        /*
        var savedState = CompraDetallePageState;
        if (savedState != null)
        {
            CompraDetalleViewModel vdm = (CompraDetalleViewModel)BindingContext;
            vdm.FormularioVisible = savedState.formulariovisible;
            vdm.DetalleActual.CompraDetReg = savedState.detalleactual;
        }
        savedState = null;
        */

        var estado = EstadoSeleccionVenta.EstadoActual;
        if (estado != null)
        {
            //FormularioVisible = estado.formulariovisible;
            //DetalleActual.CompraDetReg = estado.detalleactual;
            if (BindingContext is VentaDetalleViewModel cvm)
            {
                cvm.DetalleActual.VentaDetReg = estado.detalleactual; //.Prodid = producto.Id;
                cvm.FormularioVisible = estado.formulariovisible;
                EstadoSeleccionCompra.Limpiar(); // opcional, para no reutilizarlo m�s adelante por error

                var producto = EstadoSeleccionProducto.ProductoSeleccionado;
                if (producto != null && cvm.DetalleActual != null)
                {
                    cvm.ProductoSeleccionado = producto;
                    //vm.FormularioVisible = true;

                    // Limpia el valor almacenado
                    ProductoSeleccionadoResult.Producto = null;
                }
            }
        }




        //var producto = EstadoSeleccionProducto.ProductoSeleccionado;
        //if (producto != null && BindingContext is CompraDetalleViewModel vm && vm.DetalleActual != null)
        //{
        //vm.ProductoSeleccionado = producto;
        //vm.FormularioVisible = true;

        // Limpia el valor almacenado
        ProductoSeleccionadoResult.Producto = null;
        //}

    }

    private async void OnVolverClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(".."); // vuelve atr�s en la pila
    }

}