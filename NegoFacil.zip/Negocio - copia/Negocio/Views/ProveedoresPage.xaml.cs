namespace Negocio.Views;

public partial class ProveedoresPage : ContentPage
{
	public ProveedoresPage()
	{
		InitializeComponent();
	}
}