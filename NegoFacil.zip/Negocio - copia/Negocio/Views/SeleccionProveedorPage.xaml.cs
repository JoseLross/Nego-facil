using Negocio.Helpers;
using Negocio.Models;

namespace Negocio.Views
{
    public partial class SeleccionProveedorPage : ContentPage
    {
        public SeleccionProveedorPage()
        {
            InitializeComponent();
        }

        private async void OnProveedorSeleccionado(object sender, SelectionChangedEventArgs e)
        {
            if (e.CurrentSelection.FirstOrDefault() is Proveedor proveedor)
            {
                ProveedorSeleccionadoResult.Proveedor = proveedor;
                await Shell.Current.GoToAsync(".."); // volver a la p�gina anterior
            }
        }

        private async void OnCancelarClicked(object sender, EventArgs e)
        {
            ProveedorSeleccionadoResult.Proveedor = null;
            await Shell.Current.GoToAsync(".."); // volver sin seleccionar
        }
    }
}
