using Negocio.ViewModels;
namespace Negocio.Views;

public partial class ProductosPage : ContentPage
{
	public ProductosPage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();

        if (BindingContext is ProductosViewModel vm)
        {
            vm.CargarProductos(); // Esto recargar� el stock desde la base de datos
        }
    }

}