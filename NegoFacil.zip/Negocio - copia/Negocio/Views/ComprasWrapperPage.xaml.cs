namespace Negocio.Views;

public partial class ComprasWrapperPage : ContentPage
{
    public ComprasWrapperPage()
    {
        InitializeComponent();
        try
        {
            var page = new ComprasPage(); // aqu� puede fallar
            Content = page.Content;
            BindingContext = page.BindingContext;
        }
        catch (Exception ex)
        {
            Content = new Label
            {
                Text = "? Error al cargar la p�gina de Compras:\n" + ex.Message,
                TextColor = Colors.Red,
                Padding = 20,
                FontSize = 14
            };
        }
    }
}
