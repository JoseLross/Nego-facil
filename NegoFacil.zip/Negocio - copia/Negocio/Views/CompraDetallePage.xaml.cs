using Negocio.Helpers;
using Negocio.ViewModels;
namespace Negocio.Views;

using Negocio.ViewModels;

public partial class CompraDetallePage : ContentPage
{
    private CompraDetalleViewModel vm;
    public CompraDetallePage()
    {
        InitializeComponent();
        vm = new CompraDetalleViewModel();
        BindingContext = vm;
    }

    /*
    protected override void OnAppearing()
    {
        base.OnAppearing();
        var estado = EstadoSeleccionCompra.EstadoActual;
        if (estado != null)
        {
            if (BindingContext is CompraDetalleViewModel cvm)
            {
                cvm.DetalleActual.CompraDetReg = estado.detalleactual; //.Prodid = producto.Id;
                cvm.FormularioVisible = estado.formulariovisible;
                EstadoSeleccionCompra.Limpiar(); // opcional, para no reutilizarlo m�s adelante por error

                var producto = EstadoSeleccionProducto.ProductoSeleccionado;
                if (producto != null  && cvm.DetalleActual != null)
                {
                    cvm.ProductoSeleccionado = producto;
                    ProductoSeleccionadoResult.Producto = null;
                }
            }
        }
        ProductoSeleccionadoResult.Producto = null;
    }
    */

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        if (BindingContext is CompraDetalleViewModel cvm)
        {
            var estado = EstadoSeleccionCompra.EstadoActual;
            if (estado != null)
            {
                cvm.DetalleActual.CompraDetReg = estado.detalleactual;
                cvm.FormularioVisible = estado.formulariovisible;
                EstadoSeleccionCompra.Limpiar();

                var producto = EstadoSeleccionProducto.ProductoSeleccionado;
                if (producto != null && cvm.DetalleActual != null)
                {
                    cvm.ProductoSeleccionado = producto;
                    EstadoSeleccionProducto.ProductoSeleccionado = null;
                }
            }

            // ?? Protecci�n extra si no se carg� correctamente el HeadId (por ejemplo, si se abri� directo desde app)
            if (cvm.CompraHeadId == 0)
            {
                var heads = await DatabaseService.Database.GetCompraHeadsAsync();
                if (heads.Any())
                    cvm.CompraHeadId = heads.First().Id;
            }
        }
    }

    private async void OnVolverClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(".."); // vuelve atr�s en la pila
    }

}