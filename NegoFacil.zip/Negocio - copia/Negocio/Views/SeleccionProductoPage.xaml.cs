using Negocio.Helpers;
using Negocio.Models;

namespace Negocio.Views;

public partial class SeleccionProductoPage : ContentPage
{
    public SeleccionProductoPage()
    {
        InitializeComponent();
    }

    private async void OnProductoSeleccionado(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is Producto producto)
        {
            //EstadoSeleccionProducto.ProductoSeleccionado = producto;
            ////////EstadoSeleccionProducto.Instance.ProductoSeleccionado = producto;
            //await Shell.Current.GoToAsync("..");
        }
    }
    private async void OnCancelarClicked(object sender, EventArgs e)
    {
        //ProductoSeleccionado = null;
        await Shell.Current.GoToAsync(".."); // volver sin seleccionar
    }
}